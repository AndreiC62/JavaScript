import "./design.css";
import React from "react";

function Design() {
  return <div className="buttons"></div>;
}

export default Design;
