import "./addContact.css";
import React from "react";
import addContact from "./images.png";

function AddContact() {
  return <img src={addContact} alt="Add Contact" />;
}

export default AddContact;
